// Reviews Section Management with Photos
class ReviewsManager {
    constructor() {
        this.currentLanguage = localStorage.getItem('language') || 'en';
        this.reviews = reviewsData[this.currentLanguage] || [];
        this.init();
    }

    init() {
        this.renderReviews();
        this.attachFormListeners();
    }

    renderReviews() {
        const reviewsGrid = document.querySelector('.reviews-grid');
        reviewsGrid.innerHTML = '';

        const reviews = reviewsData[this.currentLanguage] || [];
        
        reviews.forEach(review => {
            const reviewCard = document.createElement('div');
            reviewCard.className = 'review-card';
            
            // Format date to readable format
            const dateObj = new Date(review.date);
            const formattedDate = dateObj.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
            
            reviewCard.innerHTML = `
                <div class="review-header">
                    <div class="review-avatar">
                        <img src="${review.photo}" alt="${review.name}" onerror="this.style.display='none'">
                    </div>
                    <div class="review-info">
                        <h4>${review.name}</h4>
                        <p>${formattedDate}</p>
                    </div>
                </div>
                <div class="rating">
                    ${'⭐'.repeat(review.rating)}
                </div>
                <div class="review-quote">
                    <p class="review-text">"${review.review}"</p>
                </div>
                <div class="review-meta">
                    <span class="review-verified">
                        <i class="fas fa-check-circle"></i>
                        <span class="data-i18n" key="review_verified">Verified Customer</span>
                    </span>
                </div>
            `;
            reviewsGrid.appendChild(reviewCard);
        });
        
        // Update all i18n elements in reviews
        this.updateReviewTranslations();
    }

    updateReviewTranslations() {
        const elements = document.querySelectorAll('.review-verified .data-i18n');
        elements.forEach(element => {
            const key = element.getAttribute('key') || 'review_verified';
            if (translations[this.currentLanguage][key]) {
                element.textContent = translations[this.currentLanguage][key];
            }
        });
    }

    updateReviews(language) {
        this.currentLanguage = language;
        this.renderReviews();
    }

    attachFormListeners() {
        const reviewForm = document.querySelector('.review-form');
        if (reviewForm) {
            reviewForm.addEventListener('submit', (e) => {
                e.preventDefault();
                
                const formData = new FormData(reviewForm);
                const photoInput = document.getElementById('photo-upload');
                
                const successMessage = this.currentLanguage === 'ar' 
                    ? 'شكراً لتقييمك! سيتم عرض مراجعتك مع الصورة قريباً.' 
                    : this.currentLanguage === 'fr'
                    ? 'Merci pour votre avis! Votre évaluation avec la photo sera affichée bientôt.'
                    : 'Thank you for your review! Your feedback with photo will be displayed soon.';
                
                alert(successMessage);
                reviewForm.reset();
                photoInput.value = '';
            });
        }
    }
}

// Initialize Reviews Manager when DOM is loaded
let reviewsManager;

document.addEventListener('DOMContentLoaded', () => {
    reviewsManager = new ReviewsManager();
});