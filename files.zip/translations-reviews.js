// Add these to the existing translations object in translations.js

const reviewsTranslations = {
    en: {
        nav_reviews: "Reviews",
        reviews_title: "Customer Reviews",
        reviews_subtitle: "See what our happy clients have to say about our work",
        review_form_title: "Share Your Experience",
        form_rating: "Select Rating",
        // ... other translations remain the same
    },
    fr: {
        nav_reviews: "Avis",
        reviews_title: "Avis des Clients",
        reviews_subtitle: "Découvrez ce que nos clients heureux disent de notre travail",
        review_form_title: "Partager Votre Expérience",
        form_rating: "Sélectionner une Évaluation",
        // ... other translations remain the same
    },
    ar: {
        nav_reviews: "التقييمات",
        reviews_title: "تقييمات العملاء",
        reviews_subtitle: "اطلع على ما يقوله عملاؤنا الراضون عن عملنا",
        review_form_title: "شارك تجربتك",
        form_rating: "اختر التقييم",
        // ... other translations remain the same
    }
};

// Merge with existing translations
Object.keys(reviewsTranslations).forEach(lang => {
    translations[lang] = { ...translations[lang], ...reviewsTranslations[lang] };
});