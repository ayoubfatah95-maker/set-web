const reviewsData = {
    en: [
        {
            id: 1,
            name: "John Smith",
            avatar: "J",
            photo: "https://i.pravatar.cc/150?img=1&u=john-smith",
            rating: 5,
            review: "Absolutely amazing work! The team transformed our backyard into a paradise. The attention to detail and professionalism were outstanding. Highly recommended!",
            date: "2025-11-18 13:12:13"
        },
        {
            id: 2,
            name: "Sarah Johnson",
            avatar: "S",
            photo: "https://i.pravatar.cc/150?img=2&u=sarah-johnson",
            rating: 5,
            review: "Best landscaping decision we ever made. The new garden design exceeded our expectations and the irrigation system works perfectly. Thank you!",
            date: "2025-11-17 10:45:22"
        },
        {
            id: 3,
            name: "Michael Brown",
            avatar: "M",
            photo: "https://i.pravatar.cc/150?img=3&u=michael-brown",
            rating: 4,
            review: "Great service and beautiful results. The team was professional and completed the project on time. Very satisfied with the hardscaping work.",
            date: "2025-11-16 14:30:15"
        },
        {
            id: 4,
            name: "Emily Davis",
            avatar: "E",
            photo: "https://i.pravatar.cc/150?img=4&u=emily-davis",
            rating: 5,
            review: "Outstanding! Our maintenance plan has kept our garden looking perfect. The team is responsive and takes great care of the landscaping.",
            date: "2025-11-15 09:20:45"
        },
        {
            id: 5,
            name: "David Wilson",
            avatar: "D",
            photo: "https://i.pravatar.cc/150?img=5&u=david-wilson",
            rating: 5,
            review: "The landscape lighting installation is breathtaking. It completely transformed the look of our garden at night. Professional and punctual team!",
            date: "2025-11-14 16:55:30"
        },
        {
            id: 6,
            name: "Jessica Martinez",
            avatar: "J",
            photo: "https://i.pravatar.cc/150?img=6&u=jessica-martinez",
            rating: 5,
            review: "From design to implementation, everything was perfect. Our garden is now the talk of the neighborhood. Truly exceptional work!",
            date: "2025-11-13 11:15:20"
        },
        {
            id: 7,
            name: "Robert Taylor",
            avatar: "R",
            photo: "https://i.pravatar.cc/150?img=7&u=robert-taylor",
            rating: 4,
            review: "Very impressed with the irrigation system. Water-efficient and keeps everything green. The team answered all my questions thoroughly.",
            date: "2025-11-12 13:40:08"
        },
        {
            id: 8,
            name: "Linda Anderson",
            avatar: "L",
            photo: "https://i.pravatar.cc/150?img=8&u=linda-anderson",
            rating: 5,
            review: "My garden is my sanctuary now thanks to the expert design and careful execution. The team treated my home like their own. Highly satisfied!",
            date: "2025-11-11 15:25:50"
        }
    ],
    fr: [
        {
            id: 1,
            name: "Pierre Martin",
            avatar: "P",
            photo: "https://i.pravatar.cc/150?img=9&u=pierre-martin",
            rating: 5,
            review: "Travail absolument magnifique! L'équipe a transformé notre cour arrière en paradis. L'attention aux détails et le professionnalisme étaient exceptionnels. Très recommandé!",
            date: "2025-11-18 13:12:13"
        },
        {
            id: 2,
            name: "Marie Laurent",
            avatar: "M",
            photo: "https://i.pravatar.cc/150?img=10&u=marie-laurent",
            rating: 5,
            review: "La meilleure décision en matière d'aménagement paysager! La nouvelle conception du jardin a dépassé nos attentes et le système d'irrigation fonctionne parfaitement.",
            date: "2025-11-17 10:45:22"
        },
        {
            id: 3,
            name: "Jacques Dubois",
            avatar: "J",
            photo: "https://i.pravatar.cc/150?img=11&u=jacques-dubois",
            rating: 4,
            review: "Service excellent et résultats magnifiques. L'équipe était professionnelle et a terminé le projet à temps. Très satisfait des travaux de structure.",
            date: "2025-11-16 14:30:15"
        },
        {
            id: 4,
            name: "Isabelle Rousseau",
            avatar: "I",
            photo: "https://i.pravatar.cc/150?img=12&u=isabelle-rousseau",
            rating: 5,
            review: "Exceptionnel! Notre plan d'entretien a gardé notre jardin parfait. L'équipe est réactive et prend soin de l'aménagement paysager.",
            date: "2025-11-15 09:20:45"
        },
        {
            id: 5,
            name: "Claude Leclerc",
            avatar: "C",
            photo: "https://i.pravatar.cc/150?img=13&u=claude-leclerc",
            rating: 5,
            review: "L'installation d'éclairage paysager est magnifique. Elle a complètement transformé l'apparence de notre jardin la nuit. Équipe professionnelle et ponctuelle!",
            date: "2025-11-14 16:55:30"
        },
        {
            id: 6,
            name: "Sophie Moreau",
            avatar: "S",
            photo: "https://i.pravatar.cc/150?img=14&u=sophie-moreau",
            rating: 5,
            review: "De la conception à la mise en œuvre, tout était parfait. Notre jardin est maintenant célèbre dans le quartier. Travail vraiment exceptionnel!",
            date: "2025-11-13 11:15:20"
        },
        {
            id: 7,
            name: "Henri Garnier",
            avatar: "H",
            photo: "https://i.pravatar.cc/150?img=15&u=henri-garnier",
            rating: 4,
            review: "Très impressionné par le système d'irrigation. Efficace en eau et garde tout verdoyant. L'équipe a répondu à toutes mes questions en détail.",
            date: "2025-11-12 13:40:08"
        },
        {
            id: 8,
            name: "Véronique Blanc",
            avatar: "V",
            photo: "https://i.pravatar.cc/150?img=16&u=veronique-blanc",
            rating: 5,
            review: "Mon jardin est maintenant mon sanctuaire grâce à la conception experte et l'exécution soignée. L'équipe a traité ma maison comme la leur. Très satisfait!",
            date: "2025-11-11 15:25:50"
        }
    ],
    ar: [
        {
            id: 1,
            name: "أحمد محمد",
            avatar: "أ",
            photo: "https://i.pravatar.cc/150?img=17&u=ahmed-mohammad",
            rating: 5,
            review: "عمل رائع جداً! لقد حول الفريق حديقتنا الخلفية إلى جنة. كان الاهتمام بالتفاصيل والاحترافية استثنائيين. موصى به بشدة!",
            date: "2025-11-18 13:12:13"
        },
        {
            id: 2,
            name: "فاطمة علي",
            avatar: "ف",
            photo: "https://i.pravatar.cc/150?img=18&u=fatima-ali",
            rating: 5,
            review: "أفضل قرار لتنسيق الحدائق على الإطلاق! تصميم الحديقة الجديد تجاوز توقعاتنا ونظام الري يعمل بشكل مثالي. شكراً!",
            date: "2025-11-17 10:45:22"
        },
        {
            id: 3,
            name: "محمود حسن",
            avatar: "م",
            photo: "https://i.pravatar.cc/150?img=19&u=mahmoud-hassan",
            rating: 4,
            review: "خدمة رائعة ونتائج جميلة. كان الفريق محترفاً وأنهى المشروع في الوقت المحدد. راضٍ جداً عن أعمال المنشآت الصلبة.",
            date: "2025-11-16 14:30:15"
        },
        {
            id: 4,
            name: "نور السيد",
            avatar: "ن",
            photo: "https://i.pravatar.cc/150?img=20&u=noor-alsayed",
            rating: 5,
            review: "استثنائي! خطتنا الصيانية حافظت على حديقتنا مثالية. الفريق متجاوب وعنايتهم بتنسيق الحدائق رائعة.",
            date: "2025-11-15 09:20:45"
        },
        {
            id: 5,
            name: "خالد يوسف",
            avatar: "خ",
            photo: "https://i.pravatar.cc/150?img=21&u=khaled-yousuf",
            rating: 5,
            review: "تثبيت الإضاءة الطبيعية رائع جداً. لقد غيّر مظهر حديقتنا بالكامل في الليل. فريق محترف وملتزم بالمواعيد!",
            date: "2025-11-14 16:55:30"
        },
        {
            id: 6,
            name: "ريم الحارثي",
            avatar: "ر",
            photo: "https://i.pravatar.cc/150?img=22&u=reem-alharith",
            rating: 5,
            review: "من التصميم إلى التنفيذ، كل شيء كان مثالياً. حديقتنا الآن محط أنظار الحي. عمل استثنائي حقاً!",
            date: "2025-11-13 11:15:20"
        },
        {
            id: 7,
            name: "عمر الشمري",
            avatar: "ع",
            photo: "https://i.pravatar.cc/150?img=23&u=omar-shammari",
            rating: 4,
            review: "معجب جداً بنظام الري. موفّر للمياه ويحافظ على كل شيء أخضر. أجاب الفريق على جميع أسئلتي بشكل شامل.",
            date: "2025-11-12 13:40:08"
        },
        {
            id: 8,
            name: "منال القحطاني",
            avatar: "م",
            photo: "https://i.pravatar.cc/150?img=24&u=manal-alqahtani",
            rating: 5,
            review: "حديقتي الآن ملاذي الهادئ بفضل التصميم الخبير والتنفيذ الدقيق. عاملة الفريق منزلي كأنها منزلهم. راضٍ جداً!",
            date: "2025-11-11 15:25:50"
        }
    ]
};