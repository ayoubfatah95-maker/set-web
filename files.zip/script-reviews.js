// Reviews Section Management
class ReviewsManager {
    constructor() {
        this.currentLanguage = localStorage.getItem('language') || 'en';
        this.reviews = reviewsData[this.currentLanguage] || [];
        this.init();
    }

    init() {
        this.renderReviews();
        this.attachFormListeners();
    }

    renderReviews() {
        const reviewsGrid = document.querySelector('.reviews-grid');
        reviewsGrid.innerHTML = '';

        const reviews = reviewsData[this.currentLanguage] || [];
        
        reviews.forEach(review => {
            const reviewCard = document.createElement('div');
            reviewCard.className = 'review-card';
            reviewCard.innerHTML = `
                <div class="review-header">
                    <div class="review-avatar">${review.avatar}</div>
                    <div class="review-info">
                        <h4>${review.name}</h4>
                        <p>${review.date || new Date().toLocaleDateString()}</p>
                    </div>
                </div>
                <div class="rating">
                    ${'⭐'.repeat(review.rating)}
                </div>
                <div class="review-quote">
                    <p class="review-text">"${review.review}"</p>
                </div>
            `;
            reviewsGrid.appendChild(reviewCard);
        });
    }

    updateReviews(language) {
        this.currentLanguage = language;
        this.renderReviews();
    }

    attachFormListeners() {
        const reviewForm = document.querySelector('.review-form');
        if (reviewForm) {
            reviewForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(reviewForm);
                alert(this.currentLanguage === 'ar' 
                    ? 'شكراً لتقييمك! سيتم عرض مراجعتك قريباً.' 
                    : this.currentLanguage === 'fr'
                    ? 'Merci pour votre avis! Votre évaluation sera affichée bientôt.'
                    : 'Thank you for your review! Your feedback will be displayed soon.');
                reviewForm.reset();
            });
        }
    }
}

// Initialize Reviews Manager when DOM is loaded
let reviewsManager;

document.addEventListener('DOMContentLoaded', () => {
    reviewsManager = new ReviewsManager();
});