// Add these translations to your existing translations.js

// In the 'en' object, add:
review_verified: "Verified Customer",
form_photo_help: "Optional: Upload a photo of your garden",

// In the 'fr' object, add:
review_verified: "Client Vérifié",
form_photo_help: "Facultatif: Télécharger une photo de votre jardin",

// In the 'ar' object, add:
review_verified: "عميل موثق",
form_photo_help: "اختياري: قم بتحميل صورة حديقتك",