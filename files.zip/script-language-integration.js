// Add this to your existing LanguageManager class

class LanguageManager {
    // ... existing code ...

    setLanguage(language) {
        this.currentLanguage = language;
        localStorage.setItem('language', language);
        document.documentElement.lang = language;
        document.body.setAttribute('data-lang', language);
        this.updateTranslations();
        this.updateActiveButton();
        
        // Update reviews when language changes
        if (reviewsManager) {
            reviewsManager.updateReviews(language);
        }
    }

    // ... rest of existing code ...
}