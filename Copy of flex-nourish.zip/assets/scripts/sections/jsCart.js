Shopify.theme.jsCart = {
  init: function ($section) {

    // Add settings from schema to current object
    //Shopify.theme.jsCart = $.extend(this, Shopify.theme.getSectionData($section));

    this.$section = $section;

    $(document).on('click', '[data-cart-page-delete]', function (e) {
      e.preventDefault();
      const itemKey = $(this).data('cart-item-key');
      Shopify.theme.jsCart.removeFromCart(itemKey);

      return false;
    });


  },
  removeFromCart: function (itemKey) {
    const $cartItem = Shopify.theme.jsCart.$section.find(`[data-cart-item-key="${itemKey}"]`).parents('.cart__card');

    $cartItem.css('opacity', '0.5');

    $.ajax({
      type: 'POST',
      url: '/cart/change.js',
      data: 'quantity=0&id=' + itemKey,
      dataType: 'json',
      success: function (cart) {

        $cartItem.addClass('animated zoomOut').delay(1000).queue(function () {
          $cartItem.addClass('is-hidden'); //@TODO - add nicer animation
        });

        Shopify.theme.jsCart.updateView(cart);

        if (typeof Shopify.theme.jsAjaxCart !== 'undefined') {
          Shopify.theme.jsAjaxCart.updateView();
        }
      },
      error: function (XMLHttpRequest, textStatus) {
        var response = eval('(' + XMLHttpRequest.responseText + ')');
        response = response.description;
      }
    });
  },
  updateView: function (cart, itemKey = null) {

    if (cart.item_count > 0) {
      $.ajax({
        dataType: "json",
        async: false,
        cache: false,
        dataType: 'html',
        url: "/cart",
        success: function (html) {

          if (itemKey !== null) {
            const itemTotal = $(html).find(`[data-cart-item="${itemKey}"]`).find('.cart__total');
            const quantityInput = $(html).find(`[data-cart-item="${itemKey}"]`).find('.quantity-input');

            $(`[data-cart-item="${itemKey}"]`).find('.cart__total').replaceWith(itemTotal);
            $(`[data-cart-item="${itemKey}"]`).find('.quantity-input').replaceWith(quantityInput);
          }

          const savings = $(html).find('.cart__savings');
          const subtotal = $(html).find('.cart__subtotal');

          $('.cart__savings').replaceWith(savings);
          $('.cart__subtotal').replaceWith(subtotal);

          $('[data-bind="itemCount"]').text(cart.item_count);

        }
      });

    } else {
      $('.cart__empty-cart-message').removeClass('is-hidden');
      $('.cart__form').addClass('is-hidden');
      $('[data-ajax-cart-trigger]').removeClass('has-cart-count');
      $('[data-bind="itemCount"]').text('0');
    }

    if (Shopify.theme_settings.show_multiple_currencies) {
      convertCurrencies();
    }

  },
  unload: function ($section) {
    // Clear event listeners in theme editor
    $('[data-cart-page-delete]').off();
  }
}
