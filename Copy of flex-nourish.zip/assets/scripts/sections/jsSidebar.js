Shopify.theme.jsSidebar = {
  init: function() {

    const $toggleBtn = $('[data-sidebar-block__toggle-icon]');
    const $sidebarContent = $('[data-sidebar-block__content--collapsible]');

    $toggleBtn.on('click', function(e) {
      
      e.preventDefault();

      const $clickedToggleBtn = $(this);
      const $toggleIcon = $(this).find('.icon');
      const $parentBlock = $clickedToggleBtn.closest('.sidebar__block');
      const $hiddenContent = $parentBlock.find($sidebarContent);

      if ($clickedToggleBtn.hasClass('icon-style--carets')) {
        $toggleIcon.toggleClass('icon--rotate');
      }
     
      $toggleIcon.toggleClass('icon--active');
      $hiddenContent.toggle();

    });
  },
  unload: function() {
    const $toggleBtn = $('[data-sidebar-block__toggle-icon]');
    $toggleBtn.off();
  }
}