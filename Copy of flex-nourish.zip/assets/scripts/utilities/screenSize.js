function isScreenSizeLarge() {
  if ($(window).width() > Shopify.breakpoints.medium ) {
    return true
  }
}
