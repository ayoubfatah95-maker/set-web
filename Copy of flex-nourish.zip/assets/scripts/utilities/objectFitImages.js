Shopify.theme.objectFitImages = {
  init: function () {
    objectFitImages();
  },
  unload: function () {
  }
}