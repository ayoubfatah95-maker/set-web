Shopify.theme.quantityBox = {
  init: function () {

    $('body').on('click', '[data-update-quantity]:not([disabled])', function () {
      Shopify.theme.quantityBox.updateQuantity($(this));
    });

    $('body').on('keyup keydown change', '.quantity-input', function () {
      Shopify.theme.quantityBox.updateQuantity($(this));
    });
  },
  updateQuantity: function ($el) {

    const $quantityBox = $el.parents('.product-quantity-box');
    const $input = $('.quantity-input', $quantityBox);
    const itemKey = $quantityBox.parents('[data-cart-item]').find('[data-cart-item-key]').data('cart-item-key');

    let val = parseInt($input.val());
    let valMax = 100000000000000000;
    let valMin = $input.attr('min') || 0;

    if ($input.attr('max') != null) {
      valMax = $input.attr('max');
    }

    if (isNaN(val) || val < valMin) {
      $input.val(valMin);
      return false;
    } else if (val > valMax) {
      $input.val(valMax);
      return false;
    }

    if ($el.data('update-quantity') === 'plus') {

      // Increase quantity input by one
      if (val < valMax) {
        val++;
        $input.val(val);
      }
    } else if ($el.data('update-quantity') === 'minus') {
      // Decrease quantity by one
      if (val > valMin) {
        val--;
        $input.val(val);
      }
    }

    if (val === 1 || val === 0) {
      $('.quantity-minus', $quantityBox).attr('disabled', true);
      $('.quantity-plus', $quantityBox).attr('disabled', false);
    } else if (val >= valMax) {
      $('.quantity-plus', $quantityBox).attr('disabled', true);
      $('.quantity-minus', $quantityBox).attr('disabled', false);
      $input.val(valMax);
    } else {
      $('.quantity-minus', $quantityBox).attr('disabled', false);
      $('.quantity-plus', $quantityBox).attr('disabled', false);
    }

    // Update quantity if within cart (vs on the product page)
    if ($el.parents("[data-cart-item]").length) {
      const lineID = $el.parents("[data-cart-item]").data('line-item');

      Shopify.theme.quantityBox.updateCart(itemKey, val, lineID);
    }

  },
  updateCart: function (itemKey, quantity, lineID) {

    $('.quantity-warning').removeClass('animated bounceIn');

    $.ajax({
      type: 'POST',
      url: '/cart/change.js',
      data: `quantity=${quantity}&id=${itemKey}`,
      dataType: 'json',
      success: function (cart) {

        let newQuantity = 0;
        let itemsLeftText = '';
        let quantityWarning = $(`[data-cart-item="${itemKey}"]`).find('.quantity-warning');
        let $quantityBox = $(`[data-cart-item="${itemKey}"]`).find('.product-quantity-box');

        //check to see if there are correct amount of products in array
        if (typeof cart.items[lineID] !== "undefined") {
          newQuantity = cart.items[lineID].quantity;
        }

        if (quantity > 0 && quantity != newQuantity) {
          if (newQuantity == 1) {
            itemsLeftText = Shopify.translation.product_count_one;
            quantityWarning.text(`${newQuantity} ${itemsLeftText}`);
            $('.quantity-minus', $quantityBox).attr('disabled', true);
          } else {
            itemsLeftText = Shopify.translation.product_count_other;
            quantityWarning.text(`${newQuantity} ${itemsLeftText}`);
          }
        }

        // Apply quantity warning
        quantityWarning.addClass('animated bounceIn');

        if (typeof Shopify.theme.jsAjaxCart !== 'undefined') {
          Shopify.theme.jsAjaxCart.updateView();
        }

        if (Shopify.theme.jsCart) {
          Shopify.theme.jsCart.updateView(cart, itemKey);
        }

      },
      error: function (XMLHttpRequest, textStatus) {
        var response = eval('(' + XMLHttpRequest.responseText + ')');
        response = response.description;

      }
    });

  },
  unload: function ($target) {
    $('.quantity-input').off();
    $('[data-update-quantity]').off();
  }
}
